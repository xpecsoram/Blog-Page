<?php
	// include header
    include_once 'includes/header.php';
?>

<?php
	// include menu bar
    include_once 'includes/nav.php';
?>

<div class="container">
	<div class="row">
		<div class="col-sm-12">

		    <?php
		    	// get blog id from the URL
		    	$blogid = $_GET['id'];

		    	// write sql query to fetch blog posts
		    	$sql = "SELECT * FROM blogpost WHERE id = ".$blogid;
		    	
		    	// execute sql query
		    	$result = mysqli_query($connection, $sql);
		    	
		    	// iterate post and fetch information
		    	$row = mysqli_fetch_array($result);
		    	
	    		$title = $row['title']; // title of blog
	    		$content = $row['content']; // content of blog

	    		echo '<h2 class="orange">'.$title.'</h2><br>';

	    		// generate random images
	    		echo '<img src="https://picsum.photos/1200/450" class="img-responsive img-thumbnail"> <br><br>';

	    		echo $content;
	    		
		    ?>

		    <br><br>

		    <hr/>
		    <!-- link to home page -->
		    <p><a href="<?php echo BASEURL; ?>" class="btn btn-lg btn-info">Back to home</a></p>

		</div>
	</div>
</div>

<?php
	// include footer
    include_once 'includes/footer.php';
?>