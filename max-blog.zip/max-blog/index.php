<?php
	// include header
    include_once 'includes/header.php';
?>

<?php
	// include menu bar
    include_once 'includes/nav.php';
?>

<div class="container">
	<div class="row">
		<div class="col-sm-12">
			
			<!-- page heading -->
			<h1>My Blog</h1>

			<hr/>

		    <?php
		    	// write sql query to fetch blog posts
		    	$sql = "SELECT * FROM blogpost";
		    	
		    	// execute sql query
		    	$result = mysqli_query($connection, $sql);
		    	
		    	// iterate all posts and fetch information
		    	while($row = mysqli_fetch_array($result)){
		    	
		    		$link = 'blogpost.php?id='.$row['id']; // create link for single blog
		    		$title = $row['title']; // title of blog
		    		
		    		// create and display link
		    		echo '<a href="'.$link.'" class="blog-link">'.$title.'</a>';
		    	
		    	}
		    ?>

		</div>
	</div>
</div>

<?php
	// include footer
    include_once 'includes/footer.php';
?>