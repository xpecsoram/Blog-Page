<?php
	error_reporting(1);

	// -- define site URL
	const BASEURL = 'http://localhost/max-blog';

	// -- DB credentials
	const DB_HOST = 'localhost';
	const DB_NAME = 'max_blog';
	const DB_USER = 'root';
	const DB_PASSWORD = '';
	
	// create DB connection 
	$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
?>