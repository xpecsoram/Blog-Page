<div class="footer">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				Copyright &copy; 2021. All rights reserved
			</div>
		</div>
	</div>
</div>

<!-- include jquery and bootstrap javascript libraries -->
<script src="<?php echo BASEURL;?>/js/jquery-1.11.3.min.js"></script>
<script src="<?php echo BASEURL;?>/js/bootstrap.min.js"></script>

</body>
</html>